(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;

  try {
    // If content.js is already injected, just toggle the panel
    await chrome.tabs.sendMessage(tab.id, { action: 'toggle' });
  } catch {
    // Not injected yet — inject it (this also shows the panel immediately)
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js'],
    });
  }

  window.close(); // Close the tiny popup window
})();
