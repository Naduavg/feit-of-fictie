const CHUTES_API_TOKEN = "cpk_22c93f35a19547289e84a54b52544afc.5918b0b015f25c97a840eb44691efba6.4eb3GSJh8bLkq2DdQeaj7mCutYqF0mHN";

(function () {
  'use strict';

  // ── If already injected, just toggle visibility ──────────────────────────
  const existingHost = document.getElementById('ff-host');
  if (existingHost) {
    existingHost.style.display = existingHost.style.display === 'none' ? '' : 'none';
    return;
  }

  // ── Create shadow DOM host pinned to top-right ───────────────────────────
  const host = document.createElement('div');
  host.id = 'ff-host';
  host.style.cssText = [
    'position:fixed',
    'top:16px',
    'right:16px',
    'z-index:2147483647',
    'font-family:inherit',
  ].join(';');
  document.body.appendChild(host);

  const shadow = host.attachShadow({ mode: 'open' });

  shadow.innerHTML = `
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    #panel{
      width:300px;
      background:#24346d;
      font-family:-apple-system,BlinkMacSystemFont,"Arial Rounded MT Bold","Nunito",Arial,sans-serif;
      color:#fff;
      border-radius:18px;
      overflow:hidden;
      display:flex;
      flex-direction:column;
      box-shadow:0 8px 32px rgba(0,0,0,.4);
    }
    .header{position:relative;padding:22px 20px 18px}
    .title-small{display:block;font-size:30px;font-weight:800;line-height:1.05;letter-spacing:-.5px}
    .title-large{display:block;font-size:34px;font-weight:900;line-height:1.05;letter-spacing:-.5px}
    #closeBtn{
      position:absolute;top:16px;right:16px;
      background:none;border:none;color:#fff;
      font-size:30px;font-weight:900;line-height:1;
      cursor:pointer;padding:0;opacity:.85;font-family:inherit;
    }
    #closeBtn:hover{opacity:1}
    .btn-wrap{padding:4px 20px 8px;display:flex;justify-content:center}
    #scanBtn{
      background:#c8cf0c;color:#24346d;font-weight:800;font-size:18px;
      letter-spacing:.01em;border:none;border-radius:12px;padding:11px 36px;
      cursor:pointer;box-shadow:5px 5px 0 #8ca81d;transition:transform .08s,box-shadow .08s;
    }
    #scanBtn:hover{background:#d8df1a}
    #scanBtn:active{transform:translate(5px,5px);box-shadow:0 0 0 #8ca81d}
    #scanBtn:disabled{
      background:#7a8c5a;color:#c0c8a0;
      box-shadow:3px 3px 0 #4a5a20;cursor:not-allowed;transform:none;
    }
    #loading{display:none;justify-content:center;align-items:center;padding:6px 0 16px}
    #loading-circle{
      width:32px;height:32px;
      border:3px solid rgba(255,255,255,.15);
      border-top-color:#c8cf0c;
      border-radius:50%;
      animation:spin .8s linear infinite;
    }
    @keyframes spin{to{transform:rotate(360deg)}}
    #status{
      text-align:center;font-size:11px;
      color:rgba(255,255,255,.55);min-height:14px;
      padding:0 20px 10px;
      display:flex;align-items:center;justify-content:center;gap:6px;
      line-height:1.5;
    }
    #result-card{display:none;margin:0 14px;border-radius:14px;overflow:hidden}
    .verdict-banner{
      padding:10px 16px;font-size:15px;font-weight:800;
      text-align:center;letter-spacing:.01em;
    }
    .verdict-banner.trust     {background:#c8cf0c;color:#24346d}
    .verdict-banner.mixed     {background:#69acdf;color:#24346d}
    .verdict-banner.suspicious{background:#ea7715;color:#fff}
    .verdict-banner.danger    {background:#cc1a1a;color:#fff}
    #post-count{
      display:none;
      text-align:center;
      font-size:11px;
      color:rgba(255,255,255,.5);
      padding:0 20px 4px;
      letter-spacing:.03em;
    }
    .result-body{
      background:#264b9a;padding:14px 16px;
      min-height:120px;border-radius:0 0 14px 14px;
    }
    #result-text{font-size:13px;line-height:1.65;color:#fff;white-space:pre-line}
    .page-footer{
      display:none;text-align:left;font-size:12px;font-weight:700;
      color:rgba(255,255,255,.6);letter-spacing:.01em;padding:12px 20px 18px;
      position:relative;
    }
    .page-footer a{
      position:absolute;right:20px;bottom:50%;transform:translateY(50%);
      display:flex;align-items:center;text-decoration:none;
    }
    .page-footer img{
      width:20px;height:20px;object-fit:contain;opacity:.85;cursor:pointer;
    }
    .page-footer img:hover{ opacity:1; }
  </style>

  <div id="panel">
    <div class="header">
      <span class="title-small">is het</span>
      <span class="title-large">Feit of fictie?</span>
      <button id="closeBtn" type="button" aria-label="Sluiten">&#x2715;</button>
    </div>
    <div class="btn-wrap">
      <button id="scanBtn" type="button">Controleer</button>
    </div>
    <div id="post-count"></div>
    <div id="loading"><div id="loading-circle"></div></div>
    <div id="status" aria-live="polite"></div>
    <div id="result-card">
      <div id="verdict-banner" class="verdict-banner">
        <span id="verdict-label"></span>
      </div>
      <div class="result-body">
        <div id="result-text"></div>
      </div>
    </div>
    <div class="page-footer" id="page-footer">Kijk kritisch, volg de feiten.<a id="footer-link" href="https://feitoffictie.com/" target="_blank" rel="noopener noreferrer"><img id="footer-icon" src="" alt="Meer info" /></a></div>
  </div>
  `;

  // ── Element refs ─────────────────────────────────────────────────────────
  const btn           = shadow.getElementById('scanBtn');
  const statusEl      = shadow.getElementById('status');
  const loadingEl     = shadow.getElementById('loading');
  const resultCard    = shadow.getElementById('result-card');
  const resultText    = shadow.getElementById('result-text');
  const verdictBanner = shadow.getElementById('verdict-banner');
  const verdictLabel  = shadow.getElementById('verdict-label');
  const postCount     = shadow.getElementById('post-count');
  const pageFooter    = shadow.getElementById('page-footer');
  const closeBtn      = shadow.getElementById('closeBtn');

  shadow.getElementById('footer-icon').src = chrome.runtime.getURL('informatieWit.png');

  const showLoading = (msg) => { loadingEl.style.display = 'flex'; statusEl.textContent = msg; };
  const hideLoading = () =>     { loadingEl.style.display = 'none'; statusEl.textContent = ''; };

  closeBtn.addEventListener('click', () => { host.style.display = 'none'; postCount.style.display = 'none'; });

  // ── Scan logic ───────────────────────────────────────────────────────────
  btn.addEventListener('click', async () => {
    resultCard.style.display  = 'none';
    pageFooter.style.display  = 'none';
    postCount.style.display   = 'none';
    btn.disabled = true;
    showLoading('Berichten laden…');

    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const TARGET      = 15;
    const MAX_SCROLLS = 25;

    const SELECTORS = [
      '[data-ad-comet-preview="message"]',
      '[data-ad-rendering-role="story_message"]',
      '[data-testid="post_message"]',
    ];

    const findPosts = () => {
      for (const sel of SELECTORS) {
        const els = document.querySelectorAll(sel);
        if (els.length > 0) return { sel, els: Array.from(els) };
      }
      return null;
    };

    // Collect while scrolling so Facebook's virtual DOM doesn't lose earlier posts
    const seenKeys  = new Set();
    const collected = [];

    const harvest = (sel, els) => {
      const findRoot = (el) => {
        let node = el;
        while (node.parentElement && node.parentElement !== document.body) {
          if (node.parentElement.querySelectorAll(sel).length > 1) return node;
          node = node.parentElement;
        }
        return node;
      };

      for (const body of els) {
        if (collected.length >= TARGET) break;
        const postText = (body.innerText || '').trim();
        if (!postText) continue;
        const key = postText.slice(0, 80);
        if (seenKeys.has(key)) continue;
        seenKeys.add(key);

        const root      = findRoot(body);
        const titleEl   = root.querySelector('[data-ad-rendering-role="title"]');
        const titleText = (titleEl?.innerText || '').trim();
        const comments  = Array.from(root.querySelectorAll('div[role="article"][tabindex="-1"]'))
          .map((el) => (el.innerText || '').trim()).filter(Boolean);

        collected.push({ postText, titleText, comments });
      }
    };

    let staleStreak = 0;
    let lastCount   = 0;

    for (let i = 0; i < MAX_SCROLLS; i++) {
      const found = findPosts();
      if (found) harvest(found.sel, found.els);

      if (collected.length >= TARGET) break;

      const n = found ? found.els.length : 0;
      if (n === lastCount) { if (++staleStreak >= 5) break; }
      else staleStreak = 0;
      lastCount = n;

      window.scrollBy(0, window.innerHeight * 0.85);
      await sleep(1800);
    }

    // Final harvest + expand "Meer weergeven"
    const expandBtns = Array.from(document.querySelectorAll('[role="button"]'))
      .filter((el) => /meer weergeven|see more/i.test((el.innerText || '').trim()));
    for (const b of expandBtns) b.click();
    if (expandBtns.length) await sleep(900);

    const finalFound = findPosts();
    if (finalFound) harvest(finalFound.sel, finalFound.els);

    if (collected.length === 0) {
      hideLoading();
      statusEl.textContent = 'Geen berichten gevonden. Ververs de pagina en probeer opnieuw.';
      btn.disabled = false;
      return;
    }

    showLoading(`${collected.length} berichten gevonden. Analyseren…`);

    const pageText = collected.map((p, i) => {
      let t = `[${i + 1}] ${p.postText}`;
      if (p.titleText)       t += `\nArtikel: ${p.titleText}`;
      if (p.comments.length) t += `\nReacties: ${p.comments.slice(0, 3).join(' | ')}`;
      return t;
    }).join('\n\n');

    try {
      const response = await fetch('https://llm.chutes.ai/v1/chat/completions', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${CHUTES_API_TOKEN}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'deepseek-ai/DeepSeek-V3-0324',
          messages: [
            {
              role: 'system',
              content: `Je bent De Scanner — een scherpe, licht sarcastische nepnieuws-detector ingebouwd in een browserextensie. Je helpt gebruikers beoordelen of een Facebook-pagina te vertrouwen is. Reageer altijd in het Nederlands.

Jouw taak:

1. IDENTIFICEER DE BRON. Kijk naar de URL en paginatitel. Is dit een betrouwbaar medium (NOS, RTL Nieuws, BBC, een overheidssite)? Een roddelblad? Een beroemdheid die bekendstaat om complottheorieën? Een anonieme activistenpagina? Noem de bron bij naam en laat dit zwaar wegen in je oordeel.

2. ANALYSEER DE INHOUD. Let op rode vlaggen: sensationele of emotionele taal, vage claims als "dit willen ze niet dat je weet", niet-verifieerbare beweringen, gebrek aan bronvermelding, complotretoriek, of inhoud die woede/angst wil aanwakkeren in plaats van informeren.

3. BEKIJK DE REACTIES. Zijn mensen aan het fact-checken, of versterken ze de verontwaardiging?

4. GEEF EEN OORDEEL — precies één van deze vier labels, in hoofdletters, als allereerste woord van je antwoord:
TRUST — betrouwbare, feitelijke bron zonder grote rode vlaggen
MIXED — deels betrouwbaar, maar ook sensationeel of bevooroordeeld
SUSPICIOUS — serieuze rode vlaggen; wees kritisch
DANGER — bekende complotbron, bewuste desinformatie of volledig onverifieerbare claims

Schrijf na het oordeel 2–3 bondige zinnen met je redenering. Noem de bron bij naam. Een droge opmerking is welkom, maar blijf eerlijk en onderbouwd. Gebruik taal die begrijpelijk is voor Generatie X (45–60 jaar). Geen opsommingen, geen koppen, geen markdown.`,
            },
            {
              role: 'user',
              content: `Paginatitel: ${document.title}\nURL: ${window.location.href}\n\nHier zijn de laatste ${collected.length} berichten van deze Facebook-pagina:\n\n${pageText}`,
            },
          ],
          stream: false,
          max_tokens: 300,
          temperature: 0.7,
        }),
      });

      const data = await response.json();
      if (response.status === 429) throw new Error('__429__');
      if (!response.ok) throw new Error(`${response.status} – ${data.error?.message || JSON.stringify(data)}`);

      let content = data.choices[0].message.content
        .replace(/<think>[\s\S]*?<\/think>/gi, '')
        .replace(/<thinking>[\s\S]*?<\/thinking>/gi, '')
        .trim();

      const verdictMap = {
        TRUST:      { label: 'Betrouwbaar',          cls: 'trust' },
        MIXED:      { label: 'Goed opletten',        cls: 'mixed' },
        SUSPICIOUS: { label: 'Niet te vertrouwen',   cls: 'suspicious' },
        DANGER:     { label: 'Gevaarlijk',            cls: 'danger' },
      };
      const firstWord = content.split(/\s/)[0].toUpperCase().replace(/[^A-Z]/g, '');
      const verdict   = verdictMap[firstWord] || { label: 'Resultaat', cls: 'mixed' };
      const bodyText  = firstWord in verdictMap
        ? content.replace(/^[A-Z]+\s*[–—-]?\s*/i, '').trim()
        : content;

      verdictLabel.textContent  = verdict.label;
      verdictBanner.className   = `verdict-banner ${verdict.cls}`;
      postCount.textContent     = `Gebaseerd op ${collected.length} gescande berichten`;
      postCount.style.display   = 'block';
      resultText.textContent    = bodyText;
      hideLoading();
      resultCard.style.display  = 'block';
      pageFooter.style.display  = 'block';
    } catch (err) {
      hideLoading();
      if (err.message === '__429__') {
        statusEl.textContent = 'De AI-server is even overbelast. Probeer het over een paar minuten opnieuw.';
      } else {
        statusEl.textContent = 'API-fout: ' + err.message;
      }
      console.error('[Extension] API error:', err);
    }

    btn.disabled = false;
  });

  // Allow popup.js to toggle visibility via message
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'toggle') {
      host.style.display = host.style.display === 'none' ? '' : 'none';
    }
  });

})();
