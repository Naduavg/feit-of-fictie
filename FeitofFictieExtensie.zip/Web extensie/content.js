let groenTeller = 0;
let eersteWoordGezet = false;
let currentUrl = location.href;
let warningShown = false;



setTimeout(handlePageChange, 100);


(function injectFonts() {
  if (document.getElementById("adobe-fonts")) return;

  const link = document.createElement("link");
  link.id = "adobe-fonts";
  link.rel = "stylesheet";
  link.href = "https://use.typekit.net/mmi5nep.css";

  document.head.appendChild(link);
})();



function onUrlChange() {
  if (location.href !== currentUrl) {
    currentUrl = location.href;
    handlePageChange();
  }
}

// luister naar back/forward
window.addEventListener("popstate", onUrlChange);

// hook pushState & replaceState
["pushState", "replaceState"].forEach(method => {
  const original = history[method];
  history[method] = function () {
    original.apply(this, arguments);
    onUrlChange();
  };
});


//  WOORDENLIJST 
const woordenlijst = [
  "complot",
  "complottheorie",
  "waarheidzoeker",
  "conspiracy",
  "conspiracytheorie",
  "complotdenker",
  "complotten",
  "complottheorieen",
  "complottheorieën",
  "wappie",
  "5g",
  "corona-vaccin",
  "truthseeker",
  "truth-seeker",
  "waarheidzoeker",
  "waarheid-zoeker",
  "area51",
  "pizzagate",
  "pizza-gate",
  "illuminatie",
  "illuminati",
  "hoax",
  "capitol-bestormen",
  "flatearth",
  "platteaarde",
  "flatearthbeweging",
  "flatearth",
  "flatearththeory",
  "discshape"
  ];
  
  

  
  //  SCANNEN 
  function scanNode(node) {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent.toLowerCase();
  
      for (const woord of woordenlijst) {
        if (text.includes(woord)) {
          highlight(node, woord);
          break;
        }
      }
      
    } else {
      node.childNodes.forEach(scanNode);
    }
  }

  function highlight(textNode, woord) {
    const span = document.createElement("span");
  
    span.innerHTML = textNode.textContent.replace(
      new RegExp(`(${woord})`, "gi"),
      match => {
        if (!eersteWoordGezet) {
          eersteWoordGezet = true;
          return `<mark id="eerste-woord" style="background:rgb(181, 248, 0);;">${match}</mark>`;
        }
        return `<mark style="background: rgb(181, 248, 0);;">${match}</mark>`;
      }
    );
  
    textNode.replaceWith(span);
    groenTeller++;
  }
  


  

  //console log
  function logGroenTeller() {
    // console leegmaken → dit komt altijd bovenaan
    console.clear();
    
  
    console.log(
      "%c  GROEN GEMARKEERDE WOORDEN: %d",
      `
        font-weight: bold;
        font-size: 16px;
        color: rgb(0, 0, 255);
        padding: 6px 8px 6px 34px;
      `,
      groenTeller
    );
  }

  function handlePageChange() {
    console.log("URL veranderd:", currentUrl);
  
    groenTeller = 0;
    eersteWoordGezet = false;
    warningShown = false;
  
    document.getElementById("warning-container")?.remove();
  
    document.querySelectorAll("mark").forEach(mark => {
      mark.replaceWith(mark.textContent);
    });
  
    setTimeout(() => {
      scanNode(document.body);
  
      if (groenTeller > 0) {
        showWarning();
      }
  
      logGroenTeller();
    }, 100);
  }
  
  
  


  //  MELDING MAKEN 

  function showWarning() {
    if (document.getElementById("warning-container")) return;
  
    const container = document.createElement("div");
    container.id = "warning-container";
  
    Object.assign(container.style, {
        position: "fixed",
        top: "10px",
        right: "18px",
        zIndex: "9999",
        width: "400px",
        backgroundColor: "rgb(255, 255, 255)",
        borderRadius: "10px",
        border: "3px solid blue",
        boxShadow: "8px 8px rgb(181, 248, 0)",
        padding: "15px",
        boxSizing: "border-box",
        fontFamily: '"gravita-geo-variable", sans-serif',
        display: "flex",
        flexDirection: "column"
      });

      
    container.innerHTML = `
    <div id="bovenaan" style="
        display:flex;
        justify-content:space-between;
        align-items:flex-start;
    ">
    <h1 style="
    color: blue;
    font-size: 42px;
    line-height: 36px;
    font-family: 'gravita-geo-variable', sans-serif;
    font-variation-settings: 'wght' 800;
    margin: 0;
    text-align: left;
  ">
  is het <br> feit of fictie
</h1>

      <button id="close-warning" style="
          font-size:20px;
          cursor:pointer;
          background-color:rgb(234,108,0);
          color:white;
          border:none;
          border-radius:50%;
          width:28px;
          height:28px;
      ">
        ×
      </button>
  

    </div>
  
    <p style="
    color: blue;
    font-size: 20px;
    font-family: 'avenir-next-lt-pro', sans-serif;
    font-weight: 500;
    font-style: normal;
    margin: 5px 0 2px;
    text-align: left;

  ">
      ‘Blijf kritisch, volg de feiten’
    </p>
  
    <div id="onderaan" style="
        display:flex;
        justify-content:space-between;
        align-items:flex-end;
    ">
  
      <a href="https://naduavg.github.io/Feesboek/" target="_blank" style="
          color:white;
          font-size:16px;
          background-color:rgb(234,108,0);
          padding:6px 10px;
          border-radius:8px;
          text-decoration:none;
          font-weight: 500;
      ">
        meer info
      </a>
  
      <a href="#eerste-woord">
      <img src="${chrome.runtime.getURL('LogoF.png')}"
           style="width:60px; cursor:pointer;">
    </a>
    
      
    </div>
  `;

  
  
    document.body.appendChild(container);
  
    container.querySelector("#close-warning")
      .addEventListener("click", () => container.remove());
      
  }
  
