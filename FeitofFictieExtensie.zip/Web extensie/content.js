let groenTeller = 0;
let eersteWoordGezet = false;
let currentPath = location.pathname + location.search;
let warningShown = false;
let highlightsUitgeschakeld = false;


(function injectFonts() {
  if (document.getElementById("adobe-fonts")) return;

  const link = document.createElement("link");
  link.id = "adobe-fonts";
  link.rel = "stylesheet";
  link.href = "https://use.typekit.net/mmi5nep.css";

  document.head.appendChild(link);
})();


//url veranderen de refresh
function onUrlChange() {
  const newPath = location.pathname + location.search;

  if (newPath !== currentPath) {
    currentPath = newPath;
    handlePageChange();
  }
}

// back / forward
window.addEventListener("popstate", onUrlChange);

["pushState", "replaceState"].forEach(method => {
  const original = history[method];
  history[method] = function () {
    original.apply(this, arguments);
    onUrlChange();
  };
});


//  WOORDENLIJST 
const woordenlijst = [
  "complot",
  "complottheorie",
  "waarheidzoeker",
  "conspiracy",
  "conspiracytheorie",
  "complotdenker",
  "complotten",
  "complottheorieen",
  "complottheorieën",
  "wappie",
  "5g",
  "corona-vaccin",
  "truthseeker",
  "truth",
  "truththeory",
  "truth-seeker",
  "waarheidzoeker",
  "waarheid-zoeker",
  "area51",
  "pizzagate",
  "illuminatie",
  "illuminati",
  "flatearth",
  "platteaarde",
  "flatearththeory",
  ];
  
  //  SCANNEN 
  function scanNode(node) {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent;
  
      for (const woord of woordenlijst) {
        const regex = new RegExp(`\\b${woord}\\b`, "i"); // i = case-insensitive
  
        if (regex.test(text)) {
          highlight(node, woord);
          break;
        }
      }
    } else {
      node.childNodes.forEach(scanNode);
    }
  }  

  function highlight(textNode, woord) {
    const span = document.createElement("span");
  
    span.innerHTML = textNode.textContent.replace(
      new RegExp(`(${woord})`, "gi"),
      match => {
        if (!eersteWoordGezet) {
          eersteWoordGezet = true;
          return `<mark id="eerste-woord" style="background:rgb(181,248,0); scroll-margin-top:220px;">${match}</mark>`;
        }
        return `<mark style="background: rgb(181, 248, 0);;">${match}</mark>`;
      }
    );
  
    textNode.replaceWith(span);
    groenTeller++;
  }

  function scanFacebookPagina() {
    if (highlightsUitgeschakeld) return;
  
    document.querySelectorAll("div, span").forEach(el => {
      if (
        el.children.length === 0 &&
        el.textContent &&
        el.textContent.trim().length > 0
      ) {
        scanNode(el.firstChild);
      }
    });
  }
  
  

  //console log
  function logGroenTeller() {
    // console leegmaken → dit komt altijd bovenaan
    console.clear();
    
    console.log(
      "%c  GROEN GEMARKEERDE WOORDEN: %d",
      `
        font-weight: bold;
        font-size: 16px;
        color: rgb(0, 0, 255);
        padding: 6px 8px 6px 34px;
      `,
      groenTeller
    );
  }

  function handlePageChange() {
    console.log("Nieuwe Facebook-pagina:", location.pathname);
  
    // reset alles
    highlightsUitgeschakeld = false;
    groenTeller = 0;
    eersteWoordGezet = false;
    warningShown = false;
  
    // verwijder popup
    document.getElementById("warning-container")?.remove();
  
    // verwijder oude highlights
    document.querySelectorAll("mark").forEach(mark => {
      mark.replaceWith(mark.textContent);
    });
  
    // wacht tot Facebook content klaar is
    setTimeout(() => {
      scanFacebookPagina();
    
      if (groenTeller > 0) {
        showWarning();
      }
    
      logGroenTeller();
    }, 300);
  }

  //  MELDING MAKEN 
  function showWarning() {
    if (document.getElementById("warning-container")) return;
  
    const container = document.createElement("div");
    container.id = "warning-container";
  
    Object.assign(container.style, {
        position: "fixed",
        top: "10px",
        right: "18px",
        zIndex: "9999",
        width: "400px",
        backgroundColor: "rgb(255, 255, 255)",
        borderRadius: "10px",
        border: "3px solid blue",
        boxShadow: "8px 8px rgb(181, 248, 0)",
        padding: "15px",
        boxSizing: "border-box",
        fontFamily: '"gravita-geo-variable", sans-serif',
        display: "flex",
        flexDirection: "column"
      });

      
    container.innerHTML = `
    <div id="bovenaan" style="
        display:flex;
        justify-content:space-between;
        align-items:flex-start;
    ">
    <h1 style="
    color: blue;
    font-size: 42px;
    line-height: 36px;
    font-family: 'gravita-geo-variable', sans-serif;
    font-variation-settings: 'wght' 800;
    margin: 0;
    text-align: left;
  ">
  is het <br> feit of fictie
</h1>

      <button id="close-warning" style="
          font-size:20px;
          cursor:pointer;
          background-color:rgb(234,108,0);
          color:white;
          border:none;
          border-radius:50%;
          width:28px;
          height:28px;
      ">
        ×
      </button>
  

    </div>
    <p style="
    color: blue;
    font-size: 20px;
    font-family: 'avenir-next-lt-pro', sans-serif;
    font-weight: 500;
    font-style: normal;
    margin: 5px 0 2px;
    text-align: left;
  ">
      ‘Blijf kritisch, volg de feiten’
    </p>
  
    <div id="onderaan" style="
        display:flex;
        justify-content:space-between;
        align-items:flex-end;
    ">
  
      <a href="https://naduavg.github.io/feit-of-fictie/" target="_blank" style="
          color:white;
          font-size:16px;
          background-color:rgb(234,108,0);
          padding:6px 10px;
          border-radius:8px;
          text-decoration:none;
          font-weight: 500;
      ">
        meer info
      </a>
  
      <img id="logo-scroll"
      src="${chrome.runtime.getURL('LogoF.png')}"
      style="width:60px; cursor:pointer;">
 
      
    </div>
  `;

    document.body.appendChild(container);

    const logo = container.querySelector("#logo-scroll");

    logo.addEventListener("click", () => {
      const eerste = document.getElementById("eerste-woord");
      if (!eerste) return;
    
      eerste.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    });

    
    container.querySelector("#close-warning")
    .addEventListener("click", () => {
      highlightsUitgeschakeld = true;
  
      // verwijder alle groene markeringen
      document.querySelectorAll("mark").forEach(mark => {
        mark.replaceWith(mark.textContent);
      });
  
      container.remove();
    });
  
      
  }
  
  setTimeout(handlePageChange, 500);
